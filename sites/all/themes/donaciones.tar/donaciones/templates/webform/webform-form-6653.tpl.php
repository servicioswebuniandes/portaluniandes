<form class="webform-client-form webform-client-form-6653" action="/donaciones?contacto" method="post" id="webform-client-form-6653" accept-charset="UTF-8"><div>
	<article class="txt-contact-form">
		<h1><?php print $form['#node']->title ?></h1>
		<p><?php print $form['#node']->field_descripcion_contactar['und'][0]['value'] ?></p>
	</article>
	<article class="contact-form">

<div class="form-item webform-component webform-component-textfield webform-component--nombre form-group form-item form-item-submitted-nombre form-type-textfield form-group"><input required="required" placeholder="Nombre" class="form-control form-text required" type="text" id="edit-submitted-nombre" name="submitted[nombre]" value="" size="60" maxlength="128"> <label class="control-label element-invisible" for="edit-submitted-nombre">Nombre <span class="form-required" title="Este campo es obligatorio.">*</span></label>
</div><div class="x2 form-item webform-component webform-component-textfield webform-component--telefono form-group form-item form-item-submitted-telefono form-type-textfield form-group"><input required="required" placeholder="Teléfono" class="form-control form-text required" type="text" id="edit-submitted-telefono" name="submitted[telefono]" value="" size="60" maxlength="128"> <label class="control-label element-invisible" for="edit-submitted-telefono">Teléfono <span class="form-required" title="Este campo es obligatorio.">*</span></label>
</div><div class="x2 form-item webform-component webform-component-email webform-component--e-mail form-group form-item form-item-submitted-e-mail form-type-webform-email form-group"><input required="required" class="email form-control form-text form-email required" placeholder="E-mail" type="email" id="edit-submitted-e-mail" name="submitted[e_mail]" size="60"> <label class="control-label element-invisible" for="edit-submitted-e-mail">E-mail <span class="form-required" title="Este campo es obligatorio.">*</span></label>
</div><div class="form-item webform-component webform-component-checkboxes webform-component--terminos-y-condiciones form-group form-item form-item-submitted-terminos-y-condiciones form-type-checkboxes form-group"><div id="edit-submitted-terminos-y-condiciones" class="form-checkboxes"><div class="form-item form-item-submitted-terminos-y-condiciones-0 form-type-checkbox checkbox"> <input required="required" type="checkbox" id="edit-submitted-terminos-y-condiciones-1" name="submitted[terminos_y_condiciones][0]" value="0" class="form-checkbox"><label class="control-label" for="edit-submitted-terminos-y-condiciones-1">Aceptar Términos y Condiciones</label>
</div></div> <label class="control-label element-invisible" for="edit-submitted-terminos-y-condiciones">Términos y Condiciones <span class="form-required" title="Este campo es obligatorio.">*</span></label>
</div><div class="form-item webform-component webform-component-checkboxes webform-component--recibir-informacion form-group form-item form-item-submitted-recibir-informacion form-type-checkboxes form-group"><div id="edit-submitted-recibir-informacion" class="form-checkboxes"><div class="form-item form-item-submitted-recibir-informacion-1 form-type-checkbox checkbox"><input type="checkbox" id="edit-submitted-recibir-informacion-1" name="submitted[recibir_informacion][1]" value="0" class="form-checkbox"> <label class="control-label" for="edit-submitted-recibir-informacion-1">Deseo recibir información sobre Donaciones</label>
</div></div> <label class="control-label element-invisible" for="edit-submitted-recibir-informacion">Recibir Información</label>
</div><div class="form-actions"><button class="webform-submit button-primary btn btn-default form-submit" type="submit" name="op" value="Enviar">Enviar</button>
</div><input type="hidden" name="details[sid]">
<input type="hidden" name="details[page_num]" value="1">
<input type="hidden" name="details[page_count]" value="1">
<input type="hidden" name="details[finished]" value="0">
<input type="hidden" name="form_build_id" value="form-A-HI4_GPFBYFjp6MlO6fBCGxmrBOIizU0-Qc47Csr1c">
<input type="hidden" name="form_token" value="y7pCpbGDe6K4KnhE8gNDyluu3hnZ6d5YTn8lqscWnmQ">
<input type="hidden" name="form_id" value="webform_client_form_6653">
</article>
</div></form>